#!/usr/bin/env bash

stackName='aws-resources'

stack_exists() {
    exists=$( aws cloudformation describe-stacks --stack-name ${stackName} 2>/dev/null)
    if [ "${exists}" = "" ]; then
        echo "0"
    else
        echo "1"
    fi
}

stack_create() {
    echo "Creating stack $stackName"

    aws cloudformation create-stack \
        --stack-name    ${stackName} \
        --capabilities  CAPABILITY_IAM CAPABILITY_NAMED_IAM \
        --template-body file://artifacts/template-aws-resources.json \
        --parameters    file://artifacts/parameters-aws-resources.json \
        --tags          Key=billing,Value=coreapi Key=stack,Value=aws-resources
}

stack_update() {
    echo "Updating stack $stackName"

    aws cloudformation update-stack \
        --stack-name    ${stackName} \
        --capabilities  CAPABILITY_IAM CAPABILITY_NAMED_IAM \
        --template-body file://artifacts/template-aws-resources.json \
        --parameters    file://artifacts/parameters-aws-resources.json \
        --tags          Key=billing,Value=coreapi Key=stack,Value=aws-resources
}


stack_wait_completed () {
    echo "Waiting until completed"

    while true; do
        sleep 5
        status=$(aws cloudformation describe-stacks \
            --stack-name ${stackName} \
            --query 'Stacks[0].StackStatus' \
            | tr -d \")
        echo "      [${status}]"
        if [[ "${status}" == *COMPLETE ]]; then
            break;
        fi
    done;
}

result=$( stack_exists )
if [ "${result}" = "1" ]; then
    stack_update
else
    stack_create
fi
stack_wait_completed