#!/usr/bin/env bash

if [ $# -lt 2 ]; then
  echo 'Missing required parameters'
  echo "Usage $0 <function-path> <function-name> [zip] [timeout]"
  exit 1
fi

funcPath=$1
funcName=$2
zip=${3:-"./dist/${funcName}.zip"}

zip_package() {
    pushd ${funcPath}
    npm run clean
    npm install -production
    npm run zip
    popd
}

function_exists () {
    exists=$(aws lambda get-function --function-name ${funcName} 2>/dev/null)
    if [ "${exists}" = "" ]; then
        echo "0"
    else
        echo "1"
    fi
}

update_function () {
    echo "UPDATING function $func"
    aws lambda update-function-code \
        --function-name ${funcName}  \
        --zip-file fileb://${funcPath}/${zip}
}

result=$( function_exists )
if [ "${result}" = "0" ]; then
    ./deploy-stack.sh
fi

zip_package
update_function
