
'use strict';

const url   = require('url');
const AWS   = require('aws-sdk');
const SNS   = new AWS.SNS();

const ProtocolSelector = [
    {
        "conditions": [
            /^https:\/\/.+/g
        ],
        "protocol": "http"
    },
    {
        "conditions": [
            /^https:\/\/.+/g
        ],
        "protocol": "https"
    },
    {
        "conditions": [
            /arn:aws:sns:.+/g
        ],
        "protocol": "sqs"
    },
    {
        "conditions": [
            /arn:aws:lambda:.+/g
        ],
        "protocol": "lambda"
    }
];

/**
 *
 * @param endpoint
 */
function protocolSelector( endpoint ){
    return ProtocolSelector
        .filter( _ => _.conditions.some( _ => _.test(endpoint) ) )
        .map   ( _ => _.protocol )
        .pop   ();
}

/**
 * Get Stack Dependency
 *
 * @param config {{TopicArn:String, Endpoint:String, Protocol:String }}
 * @returns {Promise}
 */
function subscribeTopic(config){
    if ( !config.TopicArn ){
        return Promise.reject(new Error('Missing TopicArn when invoking Custom::Resource'));
    }
    if ( !config.Endpoint ){
        return Promise.reject(new Error('Missing Endpoint when invoking Custom::Resource'));
    }
    let protocol = config.Protocol || protocolSelector( config.Endpoint );
    if( !protocol ){
        return Promise.reject(new Error(`Missing Protocol when invoking Custom::Resource. Unable to generate automatically the protocol from ${config.Endpoint}`));
    }
    return new Promise((resolve, reject) => {
        let query = {
            Protocol: protocol,
            TopicArn: config.TopicArn,
            Endpoint: config.Endpoint
        };
        SNS.subscribe( query, (error, data) => {
            if( error ){
                console.error('An error was detected during operation', error);
            }
            error ? reject(error) :resolve({TopicArn:config.TopicArn, Endpoint: config.Endpoint});
        });
    });
}

function listTopicSubscriptions( config ){
    return new Promise((resolve, reject) => {
        let subscriptions = [];

        function queryTopic(nextToken){
            let query = {
                NextToken: nextToken,
                TopicArn : config.TopicArn
            };
            SNS.listSubscriptionsByTopic(query, (error, data) => {
                if(error){
                    return reject(error);
                }
                subscriptions = subscriptions.concat(data.Subscriptions);
                data.NextToken ? queryTopic(data.NextToken) : resolve(subscriptions);
            });
        }
        queryTopic();
    });
}

/**
 *
 * @param config
 * @returns {Promise}
 */
function unsubscribeTopic( config ) {

    function _byEndpoint( subscription ){
        return subscription.Endpoint === config.Endpoint
    }

    if ( !config.TopicArn ){
        return Promise.reject(new Error('Missing TopicArn when invoking Custom::Resource'));
    }
    if ( !config.Endpoint ){
        return Promise.reject(new Error('Missing Endpoint when invoking Custom::Resource'));
    }
    return listTopicSubscriptions( config )
        .then( (subscriptions) => {
            let  subscriptionArn = subscriptions.filter( _byEndpoint ).map( _ => _.SubscriptionArn ).pop( );
            if( !subscriptionArn ){
                return Promise.resolve({TopicArn:config.TopicArn, Endpoint: config.Endpoint})
            }
            let query = {
                SubscriptionArn: subscriptionArn
            };
            return new Promise((resolve, reject)=> {
                SNS.unsubscribe( query, (error) => {
                    if( error ){
                        console.error('An error was detected during operation', error);
                    }
                    error ? reject(error) : resolve({TopicArn:config.TopicArn, Endpoint: config.Endpoint});
                });
            });
        });
}

/**
 * Handles the request Options
 *
 * @param options
 * @param callback
 *
 */
function request(options, callback){
    let parsedUrl  = url.parse(options.url);
    let bodyStr    = JSON.stringify(options.body);
    let isSecure   = parsedUrl.protocol === 'https:';
    let requestCfg = {
        hostname: parsedUrl.hostname,
        port    : isSecure ? 443 : 80,
        path    : parsedUrl.path,
        method  : options.method,
        headers: {
            "content-type"  : "",
            "content-length": bodyStr.length
        }
    };
    console.log(JSON.stringify({RequestConfig: requestCfg}, null, 4));
    let handler = isSecure ? require('https') : require('http');
    let request = handler.request(requestCfg, (response) => {
        callback(undefined, response);
    });
    request.on("error", error => {
        callback(error);
    });
    request.write(bodyStr);
    request.end();
}

/**
 * Returns the Stack Operation response.
 *
 * @param event {{ResponseURL:string, StackId:string, RequestId:string,LogicalResourceId:string, ResourceProperties:{StackName:String} }} Initial Event
 * @param context Invocation Context
 *
 * @returns {_handler}
 */
function stackSendResponse( event, context ){
    function _getError(error){
        if(error){
            return `${error.message}. ` || 'Unknown Error message. '
        }
        return '';
    }

    /**
     * Handles the Response operation.
     *
     * @param error Error thrown during operation
     * @param data Data collected during operation.
     * @returns {Promise}
     * @private
     */
    function _handler(error, data ){
        if( !event.ResponseURL ){
            return error ? Promise.reject(error) : Promise.resolve(data);
        }
        return new Promise((resolve, reject) => {
            var responseBody = {
                Status            : error ? 'FAILED' : 'SUCCESS',
                PhysicalResourceId: 'aws-resources-stack-dependencies',
                StackId           : event.StackId,
                RequestId         : event.RequestId,
                LogicalResourceId : event.LogicalResourceId,
                Reason            : _getError(error) + "See details in CloudWatch Log: " + (context.logStreamName || '[NOT DEFINED]'),
                Data              : data
            };
            var requestCfg = {
                url   : event.ResponseURL,
                method: "PUT",
                body  : responseBody
            };
            console.log(JSON.stringify({Answer:responseBody}, null, 4));
            request( requestCfg, (error, response) => {
                if( error ){
                    console.error('An error was detected during operation', error);
                    return reject(error);
                }
                console.log(JSON.stringify({
                    Response:{
                        statusCode:response.statusCode,
                        headers   :response.headers
                    }}, null, 4));
                resolve(data);
            });
        });
    }
    return _handler;
}

const ResourceTypeHanlder = {
    Create: subscribeTopic,
    Delete: unsubscribeTopic,
    Update: () => Promise.resolve({})
};

exports.handler = (event, context, callback) => {
    console.log(JSON.stringify(event));

    ResourceTypeHanlder[event.RequestType](event.ResourceProperties).then(
        (data)  => stackSendResponse(event, context)(undefined, data),
        (error) => stackSendResponse(event, context)(event.RequestType === 'Delete' ? undefined : error)
    ).then(
        (data ) => callback(undefined, `{"Status":"SUCCESS","Data":${JSON.stringify(data)}}`),
        (error) => callback(`{"Status":"FAILED","Message":"${e.message}"}`)
    );
};

