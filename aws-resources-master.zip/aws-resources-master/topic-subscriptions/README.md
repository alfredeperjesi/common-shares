
This project implements a Custom::Resource used to resolve Cloudformation Dependencies.
It enhances CloudFormation capabilities by allowing to execute the command:
  **aws sns subscribe --topic-arn <topic-arn> --protocol <protocol> --notification-endpoint <endpoint-arn>**

using CloudFormation.

This Custom Resource can be used like:

```json
{   
    "AWSTemplateFormatVersion": "2010-09-09",
    "Description": "Sample StackA",
    "Resources": {
        "TestTopic": {
            "Type": "AWS::SNS::Topic",
            "Properties": {
                ...
            }
        },
        "TestTopic": {
            "Type": "AWS::Lambda::Function",
            "Properties": {
                ...
            }
        },
        "TestSNSSubscription": {
            "Type": "AWS::CloudFormation::CustomResource",
            "Properties": {
                "ServiceToken": { "Fn::Join": ["",[
                    "arn:aws:lambda:", {"Ref":"AWS::Region"}, ":", {"Ref":"AWS::AccountId"}, ":function:aws-resources-topic-subscriptions"
                ]]},
                "TopicArn": {"Ref": "TestTopic" },
                "Endpoint": {"Fn::GetAtt": ["TestLambda", "Arn"] }
            }
        }
    }
}
```

# How to Update the resource:
* Do your changes & execute unitary tests;
* execute bin/deploy-lambda.sh and the code will be updated directly to lambda resource


# On Going:
* Develop some Unitary tests
* Develop some integration Tests

