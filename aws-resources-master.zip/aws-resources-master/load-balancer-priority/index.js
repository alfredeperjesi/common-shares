

"use strict";

const url   = require('url');
const AWS   = require('aws-sdk');
const ELB = new AWS.ELBv2();
const CF  = new AWS.CloudFormation();

/**
 * This method when invoked returns Stack's all resources including the ones inside inner Stacks.
 *
 * @param options
 * @returns {Promise}
 * @private
 * @param flatten
 */
function getAllResources( options, flatten ){

    function getResources ( options ){
        return new Promise((resolve, reject) => {
            const query = {
                StackName: options.StackName
            };
            console.info(`Cloudformation DescribeResources: ${JSON.stringify(query)}`);
            CF.describeStackResources(query, (error, data) => {
                console.info(error ? `Cloudformation DescribeResources - Error : ${error}` : `Cloudformation DescribeResources - Result : ${JSON.stringify(data)}`);
                error ? reject(error) : resolve(data.StackResources);
            });
        });
    }

    function isValidStackResource(resource){
        return resource.ResourceStatus !== 'DELETE_COMPLETE' && resource.ResourceType === 'AWS::CloudFormation::Stack';
    }

    function getInnerStackName(resource){
        return resource.PhysicalResourceId.match(/.+:stack\/(.+)\/.+/).slice(1).pop();
    }

    flatten = flatten || false;
    return new Promise((resolve) => {
        let resourcesAcc = [];

        getResources(options).then(
            resources => {
                let resourcesP = resources
                    .map( resource => {
                        let stackName = isValidStackResource(resource) ? getInnerStackName(resource) : undefined;
                        if( !stackName ){
                            return Promise.resolve([resource]);
                        }
                        return getAllResources({StackName: stackName}, flatten)
                            .then( innerResources => {
                                if( flatten ){
                                    return Promise.resolve([resource].concat(innerResources));
                                }else{
                                    resource.InnerResources = innerResources;
                                    return Promise.resolve([resource]);
                                }
                            });
                    });
                return Promise.all(resourcesP).then(
                    (dataAr) => {
                        let result = dataAr.reduce((acc, x) => acc.concat(x), resourcesAcc);
                        resolve(result);
                    },
                    () => resolve(resourcesAcc)
                );
            },
            () => resolve(resourcesAcc)
        )
    });
}

function getLoadBalancerRules(config){

    /**
     *
     * @param data {{Rules:{Priority}}}
     * @return Array<Number>
     */
    function extractCurPriorities(data){
        return data.Rules
            .filter( _ => _.Priority !== "default" )
            .map   ( _ => Number.parseInt(_.Priority) )
            .sort( (a, b) => a - b)
        ;
    }

    return new Promise((resolve, reject) => {
        const params = {
            ListenerArn: config.ListenerArn
        };
        console.info(`LoadBalancer - DescribeRules ${JSON.stringify(params)}`);
        ELB.describeRules(params, (error, data) => {
            console.info(error ? `LoadBalancer DescribeRules - Error ${error}` : `LoadBalancer DescribeRules - Result ${JSON.stringify(data)}`);
            if( error ){
                return reject(error);
            }
            const curPriorities = extractCurPriorities(data);

            for( let i = 1; i <= curPriorities.length; i++ ){
                if (curPriorities[i-1] != i ){
                    resolve({"NextPriorityAvailable": i});
                }
            }
            resolve({"NextPriorityAvailable": curPriorities.length + 1});
        })
    })
}
function queryFirstAvailable(config){

    return getAllResources(config, true)
        .then( resources => {
            console.info("Current Resources: ");
            console.info("\t"+ JSON.stringify(resources));
            const elbListener = resources
                    .filter( r => r.LogicalResourceId === "LoadBalancerListener" )
                    .map   ( r => r.PhysicalResourceId )
                    .pop   ()
                ;

            console.info("Elastic LoadBalancer Listener: ");
            console.info("\t"+ JSON.stringify(elbListener));
            return elbListener != null ? Promise.resolve(elbListener) : Promise.reject( new Error("Couldn't find ELB Listener"))
        })
        .then( arn => getLoadBalancerRules({ListenerArn: arn}) )
}

/**
 * Handles the request Options
 *
 * @param options
 * @param callback
 *
 */
function request(options, callback){
    const parsedUrl  = url.parse(options.url);
    const bodyStr    = JSON.stringify(options.body);
    const isSecure   = parsedUrl.protocol === 'https:';
    const requestCfg = {
        hostname: parsedUrl.hostname,
        port    : isSecure ? 443 : 80,
        path    : parsedUrl.path,
        method  : options.method,
        headers: {
            "content-type"  : "",
            "content-length": bodyStr.length
        }
    };
    console.log(JSON.stringify({RequestConfig: requestCfg}, null, 4));
    let handler = isSecure ? require('https') : require('http');
    let request = handler.request(requestCfg, (response) => {
        callback(undefined, response);
    });
    request.on("error", error => {
        callback(error);
    });
    request.write(bodyStr);
    request.end();
}

/**
 * Returns the Stack Operation response.
 *
 * @param event {{ResponseURL:string, StackId:string, RequestId:string,LogicalResourceId:string, ResourceProperties:{StackName:String} }} Initial Event
 * @param context Invocation Context
 *
 * @returns {_handler}
 */
function stackSendResponse( event, context ){
    function _getError(error){
        if(error){
            return `${error.message}. ` || 'Unknown Error message. ';
        }
        return '';
    }

    /**
     * Handles the Response operation.
     *
     * @param error Error thrown during operation
     * @param data Data collected during operation.
     * @returns {Promise}
     * @private
     */
    function _handler(error, data ){
        if( !event.ResponseURL ){
            return error ? Promise.reject(error) : Promise.resolve(data);
        }
        return new Promise((resolve, reject) => {
            const responseBody = {
                Status            : error ? 'FAILED' : 'SUCCESS',
                PhysicalResourceId: 'aws-resources-stack-dependencies',
                StackId           : event.StackId,
                RequestId         : event.RequestId,
                LogicalResourceId : event.LogicalResourceId,
                Reason            : _getError(error) + "See details in CloudWatch Log: " + (context.logStreamName || '[NOT DEFINED]'),
                Data              : data
            };
            const requestCfg = {
                url   : event.ResponseURL,
                method: "PUT",
                body  : responseBody
            };
            console.log(JSON.stringify({Answer:responseBody}, null, 4));
            request( requestCfg, (error, response) => {
                if( error ){
                    console.error('An error was detected during operation', error);
                    return reject(error);
                }
                console.log(JSON.stringify({
                    Response:{
                        statusCode:response.statusCode,
                        headers   :response.headers
                    }}, null, 4));
                resolve(data);
            });
        });
    }
    return _handler;
}


const ResourceTypeHandler = {
    Create: queryFirstAvailable,
    Delete: () => Promise.resolve({}),
    Update: queryFirstAvailable
};

exports.handler = (event, context, callback) => {
    console.log(JSON.stringify(event));

    ResourceTypeHandler[event.RequestType](event.ResourceProperties).then(
        (data)  => stackSendResponse(event, context)(undefined, data),
        (error) => stackSendResponse(event, context)(event.RequestType === 'Delete' ? undefined : error)
    ).then(
        (data ) => callback(undefined, `{"Status":"SUCCESS","Data":${JSON.stringify(data)}}`),
        (error) => callback(`{"Status":"FAILED","Message":"${error.message}"}`)
    );
};