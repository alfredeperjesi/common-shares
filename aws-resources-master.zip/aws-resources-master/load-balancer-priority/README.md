
This project implements a Custom::Resource used to dynamically resolve the LoadBalancer Priority for a Cluster.

# Example

Using the new Custom::Resource Stack-Dependencies (**aws-resources-load-balancer-priority**) dynamically generate a new Priority:

StackB
```json
{   
    "AWSTemplateFormatVersion": "2010-09-09",
    "Description": "Sample StackB",
    "Resources": {
        "Cluster":{
            "Type": "Custom::StackDepdendency",
            "Properties": {
                "ServiceToken": { "Fn::Join": ["",[
                    "arn:aws:lambda:", {"Ref":"AWS::Region"}, ":", {"Ref":"AWS::AccountId"}, ":function:aws-resources-load-balancer-priority"
                ]]},
                "StackName": "cluster-preprod"
            }
        },
        "ECSService": {
            "Type": "AWS::CloudFormation::Stack",
            "Properties": {
                "TemplateURL"  : {"Fn::Sub": ["https://s3-${AWS::Region}.amazonaws.com/${bucket}/${bucketKey}/template-common-ecs-service.json", {
                    "bucket"   : {"Ref": "CloudFormationBucket"},
                    "bucketKey": {"Ref": "CloudFormationCommonKey"}
                }]},
                "Parameters": {
                    "ApplicationName"             : {"Ref": "ApplicationName"},
                    "DeploymentEnv"               : {"Ref": "DeploymentEnv"},
                    "BuildImage"                  : {"Ref": "ApplicationName"},
                    "BuildVersion"                : {"Ref": "BuildVersion"},
                    "TaskCpuAllocation"           : {"Ref": "NotificationTaskCpuAllocation"},
                    "TaskMemoryAllocation"        : {"Ref": "NotificationTaskMemoryAllocation"},
                    "DesiredCount"                : {"Ref": "NotificationDesiredCount"},
                    "DeregistrationDelay"         : {"Ref": "DeregistrationDelay"},

                    "VpcId"                       : {"Ref": "VpcId"},
                    "ECSClusterPhysicalId"        : {"Fn::GetAtt":["ECSCluster", "EnvironmentECSClusterID"]},
                    "ECSLoadBalancerListener"     : {"Fn::GetAtt":["ECSCluster", "EnvironmentECSLoadBalancerListenerID"]},
                    "LoadBalancerListenerPriority": {"Fn::GetAtt": ["Cluster", "NextPriorityAvailable"] },
                    "DeploymentConfigMaxPercent"  : "200",
                    "DeploymentConfigMinPercent"  : "50",
                    "TaskRoleArn"                 : {"Ref":"TaskRole"}
                },
                "TimeoutInMinutes": "15"
            }
        }
    }
}
```

# How to Update the resource:
* Do your changes & execute unitary tests;
* execute bin/deploy-lambda.sh and the code will be updated directly to lambda resource


# On Going:
* Develop some Unitary tests
* Develop some integration Tests

