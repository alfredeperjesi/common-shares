'use strict';

const url   = require('url');
const aws   = require('aws-sdk');
const cf    = new aws.CloudFormation();

/**
 * Get Stack Dependency
 *
 * @param config
 * @returns {Promise}
 */
function stackDependency(config){
    if ( !config.StackName ){
        return Promise.reject(new Error('Missing StackName when invoking Custom::Resource'));
    }
    return new Promise((resolve, reject) => {

        let excludes = config.Excludes || [];

        cf.describeStacks( {StackName: config.StackName}, (error, data) => {
            if( error ){
                console.error('An error was detected during operation', error);
                return reject(error);
            }
            let responseData = data.Stacks[0].Outputs
                .filter( _        => excludes.indexOf(_.OutputKey) === -1 )
                .reduce( (acc, x) => Object.assign(acc, {[x.OutputKey]:x.OutputValue}), {});
            resolve(responseData);
        });
    });
}

/**
 * Handles the request Options
 *
 * @param options
 * @param callback
 *
 */
function request(options, callback){
    let parsedUrl  = url.parse(options.url);
    let bodyStr    = JSON.stringify(options.body);
    let isSecure   = parsedUrl.protocol === 'https:';
    let requestCfg = {
        hostname: parsedUrl.hostname,
        port    : isSecure ? 443 : 80,
        path    : parsedUrl.path,
        method  : options.method,
        headers: {
            "content-type"  : "",
            "content-length": bodyStr.length
        }
    };
    console.log(JSON.stringify({RequestConfig: requestCfg}, null, 4));
    let handler = isSecure ? require('https') : require('http');
    let request = handler.request(requestCfg, (response) => {
        callback(undefined, response);
    });
    request.on("error", error => {
        callback(error);
    });
    request.write(bodyStr);
    request.end();
}

/**
 * Returns the Stack Operation response.
 *
 * @param event {{ResponseURL:string, StackId:string, RequestId:string,LogicalResourceId:string, ResourceProperties:{StackName:String} }} Initial Event
 * @param context Invocation Context
 *
 * @returns {_handler}
 */
function stackSendResponse( event, context ){
    function _getError(error){
        if(error){
            return `${error.message}. ` || 'Unknown Error message. '
        }
        return '';
    }

    /**
     * Handles the Response operation.
     *
     * @param error Error thrown during operation
     * @param data Data collected during operation.
     * @returns {Promise}
     * @private
     */
    function _handler(error, data ){
        if( !event.ResponseURL ){
            return error ? Promise.reject(error) : Promise.resolve(data);
        }
        return new Promise((resolve, reject) => {
            var responseBody = {
                Status            : error ? 'FAILED' : 'SUCCESS',
                PhysicalResourceId: 'aws-resources-stack-dependencies',
                StackId           : event.StackId,
                RequestId         : event.RequestId,
                LogicalResourceId : event.LogicalResourceId,
                Reason            : _getError(error) + "See details in CloudWatch Log: " + (context.logStreamName || '[NOT DEFINED]'),
                Data              : data
            };
            var requestCfg = {
                url   : event.ResponseURL,
                method: "PUT",
                body  : responseBody
            };
            console.log(JSON.stringify({Answer:responseBody}, null, 4));
            request( requestCfg, (error, response) => {
                if( error ){
                    console.error('An error was detected during operation', error);
                    return reject(error);
                }
                console.log(JSON.stringify({
                    Response:{
                        statusCode:response.statusCode,
                        headers   :response.headers
                }}, null, 4));
                resolve(data);
            });
        });
    }
    return _handler;
}

exports.handler = (event, context, callback) => {
    console.log(JSON.stringify(event));
    (event.RequestType !== 'Delete' ? stackDependency(event.ResourceProperties) : Promise.resolve({}))
        .then(
            (data)  => stackSendResponse(event, context)(undefined, data),
            (error) => stackSendResponse(event, context)(error)
        )
        .then(
            (data ) => callback(undefined, `{"Status":"SUCCESS","Data":${JSON.stringify(data)}}`),
            (error) => callback(`{"Status":"FAILED","Message":"${e.message}"}`)
        )
};
