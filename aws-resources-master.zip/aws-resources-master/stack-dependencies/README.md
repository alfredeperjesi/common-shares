
This project implements a Custom::Resource used to resolve Cloudformation Dependencies.
It allow us to use Stacks' to resuse the output of a stack in another one, thus removing the necessity for hardcoding values.

# Example
Given a StackA where a DynamoDB table is deployed and a StackB where the StackA's Table Stream ARN is requested to setup 
the lambda's event source we can easily resolve this dependency using:
 * *hardcoded value in StackB parameters*
 * *creating a script that resolve the dependecy and injects the value in StackB parameters*

StackA:
```json
{   
    "AWSTemplateFormatVersion": "2010-09-09",
    "Description": "Sample StackA",
    "Resources": {
        "StackDynamoDB": {
            "Type": "AWS::DynamoDB::Table",
            "Properties": {
                "TableName":"MyTable"
                ...
            }
        }
    },
    "Outputs": {
        "MyTableStream": {
            "Description": "API Gateway Endpoint",
            "Value": { "Fn::GetAtt": ["StackDynamoDB", "StreamArn"] }
        }
    }
}
```
 
StackB:
```json
{   
    "AWSTemplateFormatVersion": "2010-09-09",
    "Description": "Sample StackB",
    "Parameters": {
        "MyTableStream": {
            "Description": "My Table Stream Reference",
            "Type":"String"
        }
    },
    "Resources": {
        "LambdaStackB": {
            "Type": "AWS::Lambda::Function",
            "Properties": {
                ...
            }
        },
        "LambdaEventSourcing": {
            "Type":"AWS::Lambda::EventSourceMapping",
            "Properties": {
                "BatchSize"        : 100,
                "Enabled"          : true,
                "EventSourceArn"   : {"Ref": "MyTableStream" },
                "StartingPosition" : "LATEST",
                "FunctionName"     : {"Ref": "LambdaStackB"}
            }
        }
    }
}
```

Using the new Custom::Resource Stack-Dependencies (**aws-resources-stack-rependencies**) we can resolve this dependency without 
having huge scripts:

StackB
```json
{   
    "AWSTemplateFormatVersion": "2010-09-09",
    "Description": "Sample StackB",
    "Resources": {
        "StackAResources":{
            "Type": "Custom::StackDepdendency",
            "Properties": {
                "ServiceToken": { "Fn::Join": ["",[
                    "arn:aws:lambda:", {"Ref":"AWS::Region"}, ":", {"Ref":"AWS::AccountId"}, ":function:aws-resources-stack-dependencies"
                ]]},
                "StackName": "${StackA-Name}"
            }
        },
        "LambdaStackB": {
            "Type": "AWS::Lambda::Function",
            "Properties": {
                ...
            }
        },
        "LambdaEventSourcing": {
            "Type":"AWS::Lambda::EventSourceMapping",
            "Properties": {
                "BatchSize"        : 100,
                "Enabled"          : true,
                "EventSourceArn"   : {"Fn::GetAtt": ["StackAResources", "MyTableStream"] },
                "StartingPosition" : "LATEST",
                "FunctionName"     : {"Ref": "LambdaStackB"}
            }
        }
    }
}
```

# How to Update the resource:
* Do your changes & execute unitary tests;
* execute bin/deploy-lambda.sh and the code will be updated directly to lambda resource


# On Going:
* Develop some Unitary tests
* Develop some integration Tests

