node {
    def projectName      = "commerce-configuration-service"
    def pipeline_version = "1.1.0-b${env.BUILD_NUMBER}"
    def github_branch    = "master"

    stage("Checkout"){
        echo "git checkout"
        checkout changelog: false, poll: false, scm: [
                $class: 'GitSCM',
                branches: [[
                                   name: "${github_branch}"
                           ]],
                doGenerateSubmoduleConfigurations: false,
                extensions: [[
                                     $class: 'WipeWorkspace'
                             ], [
                                     $class: 'CleanBeforeCheckout'
                             ]],
                submoduleCfg: [],
                userRemoteConfigs: [[
                                            credentialsId: 'fe000f7c-4de6-45c7-9097-d1fba24f3cb5',
                                            url: "git@github.com:telegraph/${projectName}.git"
                                    ]]
        ]
    }

    stage("Build & Test"){
        withMaven(jdk: 'JDK8', maven: 'Maven3.3.9') {
            sh 'mvn clean install'
        }
    }

    stage("Static Update"){
        withEnv(["PATH+NODE=${tool name: 'Node7.7.2', type: 'jenkins.plugins.nodejs.tools.NodeJSInstallation'}/bin"]) {
            sh """
              cd infrastructure/scripts
              npm install;
              npm run deploy-env -- --profile static --stack-path ../cloudformation/static --template-file template-commerce-configuration-service.json --key commerce-configuration-service/commerce-configuration-service-infrastructure/cloudformation/static --bucket artifacts-repo  --aws commerce-prod
            """
        }
    }

    stage("Publish"){
        docker.withRegistry('https://553346130293.dkr.ecr.eu-west-1.amazonaws.com', 'ecr:eu-west-1:jenkins-commerce-prod') {
            docker.build("${projectName}:${pipeline_version}").push()
            sh "docker rmi 553346130293.dkr.ecr.eu-west-1.amazonaws.com/${projectName}:${pipeline_version}"
            sh "docker rmi ${projectName}:${pipeline_version}"
        }
    }

    stage("PreProd Deploy"){
        withEnv(["PATH+NODE=${tool name: 'Node7.7.2', type: 'jenkins.plugins.nodejs.tools.NodeJSInstallation'}/bin"]) {
            sh """
              cd infrastructure/scripts
              npm run deploy-env -- --profile preprod --stack-path ../cloudformation/dynamic --template-file template-commerce-configuration-service.json --key commerce-configuration-service/commerce-configuration-service-infrastructure/cloudformation/dynamic --bucket artifacts-repo --build ${pipeline_version}  --aws commerce-preprod
            """
        }
    }

    stage('Prod Manual Deploy') {
        input "Would you like to deploy this version to PROD?"
    }

    stage("Prod Deploy"){
        withEnv(["PATH+NODE=${tool name: 'Node7.7.2', type: 'jenkins.plugins.nodejs.tools.NodeJSInstallation'}/bin"]) {
            sh """
              cd infrastructure/scripts
              npm run deploy-env -- --profile prod --stack-path ../cloudformation/dynamic --template-file template-commerce-configuration-service.json --key commerce-configuration-service/commerce-configuration-service-infrastructure/cloudformation/dynamic --bucket artifacts-repo --build ${pipeline_version}  --aws commerce-prod
            """
        }
    }

}
