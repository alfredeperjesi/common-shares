node {
    def projectName      = "commerce-configuration-service"
    def pipeline_version = "${env.VERSION}"
    def github_branch    = "master"
    def environment      = "${env.ENV}"
    def aws              = (environment == "prod") ? "commerce-prod":"commerce-preprod"

    stage("Checkout"){
        echo "git checkout"
        checkout changelog: false, poll: false, scm: [
                $class: 'GitSCM',
                branches: [[
                                   name: "${github_branch}"
                           ]],
                doGenerateSubmoduleConfigurations: false,
                extensions: [[
                                     $class: 'WipeWorkspace'
                             ], [
                                     $class: 'CleanBeforeCheckout'
                             ]],
                submoduleCfg: [],
                userRemoteConfigs: [[
                                            credentialsId: 'fe000f7c-4de6-45c7-9097-d1fba24f3cb5',
                                            url: "git@github.com:telegraph/${projectName}.git"
                                    ]]
        ]
    }

    stage("Deploy"){
        withEnv(["PATH+NODE=${tool name: 'Node7.7.2', type: 'jenkins.plugins.nodejs.tools.NodeJSInstallation'}/bin"]) {
            sh """
              cd infrastructure/scripts
              npm install;
              npm run deploy-env -- --profile ${environment} --stack-path ../cloudformation/dynamic --template-file template-commerce-configuration-service.json --key commerce-configuration-service/commerce-configuration-service-infrastructure/cloudformation/dynamic --bucket artifacts-repo --build ${pipeline_version} --aws ${aws}
            """
        }
    }
}
