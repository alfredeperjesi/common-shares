#!/bin/bash

exec java -Djava.security.egd=file:/dev/./urandom -Dspring.profiles.active=${ENVIRONMENT} -javaagent:/opt/newrelic/newrelic.jar -Dnewrelic.environment=${ENVIRONMENT} -jar /app.jar