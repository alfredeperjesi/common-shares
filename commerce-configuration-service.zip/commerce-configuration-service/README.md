# platforms-configuration-service
Centralised configuration service
