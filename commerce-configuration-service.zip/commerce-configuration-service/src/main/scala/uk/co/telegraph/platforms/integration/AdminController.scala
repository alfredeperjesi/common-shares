package uk.co.telegraph.platforms.integration

import javax.servlet.http.{HttpServletRequest, HttpServletResponse}

import org.springframework.beans.factory.annotation.Value
import org.springframework.web.bind.annotation.{RequestMapping, RequestMethod, RestController}

/**
 * This Rest Controller makes available all /admin/\* requests
 * through the AWS LoadBalancer. It makes it easier to test if
 * endpoints like /admin/health are working properly
 *
 */
@RestController
@RequestMapping(
  method = Array(RequestMethod.GET),
  path   = Array("${spring.cloud.config.server.prefix:}")
)
class AdminController {

  @Value("${spring.cloud.config.server.prefix:}")
  var pathPrefix:String = _

  @RequestMapping(Array("/admin/*"))
  def adminRedirect(request: HttpServletRequest, response:HttpServletResponse):Unit = {
    val path = request.getServletPath.replaceFirst(pathPrefix, "")
    request.getRequestDispatcher(path).forward(request, response)
  }
}
