package uk.co.telegraph.platforms.integration

import com.fasterxml.jackson.databind.ObjectMapper
import org.springframework.boot.env.PropertySourceLoader
import org.springframework.core.env.{MapPropertySource, PropertySource}
import org.springframework.core.io.Resource
import org.springframework.util.ClassUtils

import scala.util.{Failure, Success, Try}

class JsonPropertySourceLoader extends PropertySourceLoader{

  import JsonPropertySourceLoader._

  val getFileExtensions: Array[String] = Array(JSON)

  override def load(name: String, resource: Resource, profile: String): PropertySource[_] = {
    if ( profile == null || !ClassUtils.isPresent("com.fasterxml.jackson.databind.ObjectMapper", null)) {
      return null
    }
    process(resource) match {
      case Success(source) =>
        new MapPropertySource(name, source)
      case Failure(e) =>
        throw new IllegalStateException(e)
    }
  }

  def process(resource:Resource):Try[MapObject] = {
    Try{ new ObjectMapper().readValue[MapObject](resource.getInputStream, classOf[MapObject]) }
  }
}

object JsonPropertySourceLoader{
  private type MapObject = java.util.Map[String, Object]
  private val JSON = "json"
}